#Ejercicio1
#Escribir un programa que pida al usuario su peso y estatura y calcule el índice de masa corporal
while True:  #Este while hace que se repita el programa hasta que los datos que se hayan introducidos sean correctos
    peso=input("Ingresa tu peso en kg: ").replace(",",".")
    alt=input("Ingresa tu altura en metros: ").replace(",",".")
#No cambio los valores a float todavia para poder aceptar cualquier respuesta y redirigir a un error si el valor no es valido evitando que se rompa el programa.
    try:
        peso=float(peso)
        alt=float(alt)
    except ValueError:      #Si los datos no son float se ejecuta
        print("Los datos ingresados no son válidos")
        continue #Vuelve al inicio del bucle
    else:
        if alt<=0 or peso<=0:
            print("Los datos ingresados no son válidos")   #Comprobamos si los datos introducidos son menor o igual que 0
            continue #Vuelve al inicio del bucle
        else:
            indmass = round(peso / (alt ** 2), 2) #Fórmula IMC
            print(f"Tu índice de masa corporal es {indmass}kg/m²")
            break #Finaliza el bucle