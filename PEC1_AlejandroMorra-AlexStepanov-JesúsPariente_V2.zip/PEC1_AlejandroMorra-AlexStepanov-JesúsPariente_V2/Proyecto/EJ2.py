#Ejercicio 2
#Escribir un programa que lea un entero positivo, n, introducido por el usuario y después muestre en pantalla la suma de todos los enteros desde 1 hasta n.

while True:
    num=input("Ingrese un número entero y positivo: ")
    try:
        num=float(num)
    except ValueError:    #Si los datos no son float se ejecuta
        print("No se ha ingresado un número.")
        continue   #Vuelve al inicio del bucle
    else:   #Una vez comprobado lo anterior comprobamos si es pósitivo y entero
        if num<0:
            print("El número debe ser positivo")
            continue   #Vuelve al inicio del bucle
        elif num!=int(num):
            print("Debe ingresar un número entero")
            continue   #Vuelve al inicio del bucle
        else:
            Suma = round((num * (num + 1)) / 2) #Formula para calcular la suma de los numeros previos
            print(f"La suma de todos los números enteros previos es {Suma}")
            break   #Finaliza el bucle