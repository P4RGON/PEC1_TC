#Ejercicio 7
#Escribir un programa que pida al usuario que introduzca una frase en la consola y muestre por pantalla la frase invertida.
frase=input("Ingrese una frase: ")
invert=frase[::-1] #[Sin inicio establecido: sin fin establecido:En orden negativo]
print(invert)