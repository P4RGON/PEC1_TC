#Ejercicio 5
#Escribir un programa que pida al usuario que introduzca una frase en la consola y una vocal
#y después muestre por pantalla la misma frase pero con la vocal introducida en mayúscula.
while True:
    frase=input("Ingrese una frase: ")
    vocalInput=input("Ingrese una vocal: ")
    if not vocalInput:
        print("No ha ingresado ninguna vocal")
        continue
    else:
        #Aqui por si se ingresa un valor sin querer como una que antes de dar enter, se limita la vocal al primer caracter ingresado
        vocal=vocalInput[0]
        #Convierto la vocal elegida a minuscula para evitar errores con mayusculas y minuslusculas.
        vocal=vocal.lower()
        if vocal in "aeiou":
            cuenta=frase.count(vocal)
            if cuenta==0:
                print("No existe la vocal ingresada en la frase.")
                continue
            else:
                print(frase.replace(vocal,vocal.upper()))
                break
        else:
            print('La "vocal" ingresada no es una vocal.')
            continue