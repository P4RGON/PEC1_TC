#Ejercicio 6
#Escribir un programa que pregunte el nombre del usuario en la consola y después de que el usuario lo introduzca muestre por pantalla <NOMBRE> tiene <n> letras
user=input("Ingrese su usuario: ")
userlen=int(len(user))
#creo variables para contar espacios en blanco y numeros dentro del string para poder contar las letras en si.
space=user.count(" ")
num=0
#Cuenta los numeros para restarlos de la longitud total de caracteres.
for c in user:
    if c.isdigit():
        num+=1
        userlen-=1
#Usa los espacios contados al principio para restarlos de la longitud total de caracteres.
if space>=1:
    userlen-=space
UPuser=user.upper()
print(f"Su nombre, {UPuser} tiene {userlen} letras y {num} numeros.")