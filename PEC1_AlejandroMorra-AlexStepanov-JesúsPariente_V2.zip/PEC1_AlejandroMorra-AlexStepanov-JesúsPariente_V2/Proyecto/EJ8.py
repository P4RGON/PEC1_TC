#Ejercicio 8
#Escribe un programa que le pida al usuario un tweet, y que le devuelva el numero de hashtag que contiene.
while True:
    tweet = input("Ingrese un tweet: ")
    hashtags=tweet.count("#") #Cuenta los hashtags en el tweet
    if hashtags==0:
        print("No hay hashtags")
        continue
    else:
        print(f"El numero de hashtags en el tweet es de {hashtags}")
        break