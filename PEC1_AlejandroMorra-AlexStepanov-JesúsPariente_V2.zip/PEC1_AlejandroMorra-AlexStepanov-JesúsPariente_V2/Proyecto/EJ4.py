#Ejercicio 4
#Escribir un programa que pregunte por un número de teléfono con este formato y muestre por pantalla el número de teléfono sin el prefijo y la extensión.
while True:
    print("Formato de número de telefono aceptado +12-123456789-12")
    FullNum=input("Ingrese el numero de telefono: ")
    #en el if añado que obligatoriamente tenga el mas, tenga numero donde deba tenerlos y los guiones igual para evitar que se rompa el programa.
    if len(FullNum)==16 and FullNum[0]=="+" and FullNum[3]=="-" and FullNum[13]=="-" and FullNum[1:3].isdigit() and FullNum[4:13].isdigit() and FullNum[14:].isdigit():
        #El .split divide en una lista cada vez que hay un guion.
        Div=FullNum.split("-")
        Pref=Div[0]
        Num=Div[1]
        Ext=Div[2]
        print(f"El prefijo es {Pref}, el numero es {Num} y la extension es {Ext}.")
        break
    else:
        print("Error, formato incorrecto.")
        continue