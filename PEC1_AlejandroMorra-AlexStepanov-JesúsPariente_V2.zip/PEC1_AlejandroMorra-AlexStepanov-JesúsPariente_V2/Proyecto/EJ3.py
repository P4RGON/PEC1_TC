#Ejercicio 3
# Escribir un programa que lea el número de payasos y muñecas vendidos en el último pedido y calcule el peso total del paquete que será enviado.
while True:
    clown=input("Ingrese el numero de payasos vendidos: ")
    doll=input("Ingrese el numero de muñecas vendidas: ")
#Pruebo si se ha ingresado un entero o no para redirigir a un error y que no se rompa el programa
    try:
        clown=int(clown)
        doll=int(doll)
    except ValueError:  #Si no es int ejecutamos la siguiente linea
        print("Error, ingrese un valor numerico entero")
        continue
    else:
        #Si se han introducido numeros enteros valido que sean positivos
        if clown<0 or doll<0:
            print("Error, no se puede ingresar valores negativos")
            continue
        else:
            #Calculo de los pesos (Nombro nuevas variables como W(de Weight) y Doll/Clown para mantener las anteriores variables por si se les quiere dar otro uso
            WClown=clown*112
            WDoll=doll*75
            total=WClown+WDoll
            print(f"El peso total del paquete es {total}g")
            break