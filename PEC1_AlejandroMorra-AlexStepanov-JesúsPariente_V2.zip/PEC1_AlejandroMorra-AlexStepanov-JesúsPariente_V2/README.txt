Para abrir el código fuente sin que se abra el ejecutable:

1. Seleccione el programa con el click derecho y elija la opción "Abrir con".

2. Abra el programa con IDLE o PyCharm.



Créditos:

Alejandro Morra, Alex Stepanov, Jesús Pariente.